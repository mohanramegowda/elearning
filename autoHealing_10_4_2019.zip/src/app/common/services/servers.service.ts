import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {ConstantsURL} from '../../common/constants/constants-urls-local';

@Injectable({
  providedIn: 'root'
})
export class ServersService {

  constructor(private _http: HttpClient) { }

  getServersList(){
    return this._http.get(ConstantsURL.SVR_Getservers);
  }

  updateServerInfo(serverID ,updatedInfo) {
    return this._http.put(ConstantsURL.SVR_Updateservers + serverID, updatedInfo);
  }

  deleteServerInfo(serverID) {
    return this._http.delete(ConstantsURL.SVR_Deleteserver + serverID);
  }
}
