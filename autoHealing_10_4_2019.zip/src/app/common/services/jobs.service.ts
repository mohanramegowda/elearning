import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {ConstantsURL} from '../../common/constants/constants-urls-local';

@Injectable()
export class JobsService {

  public jobsList = [];

  constructor(private _http: HttpClient) { }

  getJobsList() {
    return this._http.get(ConstantsURL.JBS_GetJobs);
  }

  addNewMSJob(msJobData, serverId) {
    let url = ConstantsURL.JBS_PostJobs + serverId;
    return this._http.post(url, msJobData);
  }

  updateMSJob(jobId, msUpdatedJobData){
    let url = ConstantsURL.JBS_UpdateJobs + jobId;
    return this._http.put(url, msUpdatedJobData);
  }

  deleteMSJob(jobID){
    return this._http.delete(ConstantsURL.JBS_DeleteJob + jobID);
  }

}