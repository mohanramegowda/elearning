import { environment } from "src/environments/environment";

const baseUrl = environment.apiUrl;

export const ConstantsURL = {
    JBS_GetJobs: `${baseUrl}` + `autohealing/alljobs/${localStorage.getItem('apps') ? localStorage.getItem('apps') : '*'}`,
    JBS_PostJobs: `${baseUrl}` + 'autohealing/job/',
    JBS_UpdateJobs: `${baseUrl}` + 'autohealing/job/',
    JBS_DeleteJob: `${baseUrl}` + 'autohealing/job/',
    SVR_Getservers: `${baseUrl}` + `autohealing/servers/${localStorage.getItem('apps') ? localStorage.getItem('apps') : '*'}`,
    SVR_Postservers: `${baseUrl}` + 'autohealing/server/',
    SVR_Updateservers: `${baseUrl}` + 'autohealing/server/',
    SVR_Deleteserver: `${baseUrl}` + 'autohealing/server/'
}