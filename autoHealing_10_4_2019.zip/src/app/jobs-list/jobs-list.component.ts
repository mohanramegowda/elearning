import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { JobsService } from '../common/services/jobs.service';
import { interval, Subscription } from 'rxjs';
import { ServersService } from '../common/services/servers.service';

@Component({
  selector: 'app-jobs-list',
  templateUrl: './jobs-list.component.html',
  styleUrls: ['./jobs-list.component.css']
})
export class JobsListComponent implements OnInit, OnDestroy {
  @ViewChild('editModal') editModal: ElementRef;
  @ViewChild('deleteModal') deleteModal: ElementRef;
  @ViewChild('addJobsModal') addJobsModal: ElementRef;
  @ViewChild('infoModal') infoModal: ElementRef;
  @ViewChild('erroMessage') errorModal: ElementRef;

  public jobsData;
  public allServers;
  private intervalVal: Subscription;
  public dataDeleted: any;
  public toggleEditMode: boolean = true;
  public createToggleEditMode: boolean = true;
  editForm: FormGroup;
  addJobsForm: FormGroup;
  infoForm: FormGroup;
  showLoader: boolean = false;
  errorMessage: string;
  checked: boolean = true;
  serverID;
  private healthCheckUrl: string;
  showEditHealthCheckUrl: boolean = true;

  constructor(private jobs: JobsService, private fb: FormBuilder, private server: ServersService) {
    this.infoForm = this.fb.group({
      msAppName: '',
      msEligibilityCommand: '',
      msCoundCriteria: '',
      msLaunchingCommand: '',
      msPortExpression: '',
      msHealthCheckURL: '',
      msNoOfInstances: '',
      msNoOfInstancesActive: '',
      msPortNumber: '',
      active: '',
      microservice: "true",
      healthCheckURL: "true",
      serverInfoName: '',
      createdAt: '',
      updatedAt: '',
    });

    this.editForm = this.fb.group({
      msAppName: '',
      msEligibilityCommand: '',
      msCoundCriteria: '',
      msLaunchingCommand: '',
      msPortExpression: '',
      msHealthCheckURL: '',
      msNoOfInstances: '',
      msPortNumber: '',
      active: '',
      id: '',
      microservice: "true",
      healthCheckURL: "true",
      serverInfo: '',
      serverInfoName: '',
      createdAt: '',
      updatedAt: '',
    });

    this.addJobsForm = this.fb.group({
      msAppName: ['', Validators.required],
      msEligibilityCommand: ['', Validators.required],
      msCoundCriteria: '',
      msLaunchingCommand: ['', Validators.required],
      msPortExpression: ['', Validators.required],
      msHealthCheckURL: ['', Validators.required],
      msNoOfInstances: ['', Validators.required],
      msPortNumber: ['', Validators.required],
      active: true,
      microservice: "true",
      healthCheckURL: "true",
      serverInfoName: ''
    });
  }
  modalSelection;

  ngOnInit() {
    this.showLoader = true;
    this.getAllJobs();
    this.intervalVal = interval(30000).subscribe(() => { this.getAllJobs(); });
    this.server.getServersList().subscribe((res) => {
      this.allServers = res;
    });
  }

  getAllJobs() {
    this.jobs.getJobsList().subscribe(res => {
      this.jobsData = res;
      //this.jobsData.map((v) => {v.servicesRunning = Math.floor(Math.random() * 11)});
      this.showLoader = false;
    }, error => {
      this.showLoader = false;
      console.log(error);
    }
    );
  }


  // Modal Related codes start

  commonSwitchCaseFunction(data) {
    switch (data) {
      case 'edit':
        this.editForm.reset();
        this.modalSelection = this.editModal;
        break;
      case 'delete':
        this.modalSelection = this.deleteModal;
        break;
      case 'jobs':
        this.addJobsForm.reset();
        this.modalSelection = this.addJobsModal;
        break;
      case 'info':
        this.modalSelection = this.infoModal;
        break;
      case 'error':
        this.modalSelection = this.errorModal;
    }
  }

  closeModal(data) {
    this.commonSwitchCaseFunction(data);
    this.modalSelection.nativeElement.style.display = 'none';
  }

  showModal(data) {
    this.commonSwitchCaseFunction(data);
    this.modalSelection.nativeElement.style.display = 'block';
  }


  // Delete code

  onClickDeleteRow(deleteData) {
    this.dataDeleted = deleteData;
    this.deleteModal.nativeElement.style.display = 'block';
    return this.dataDeleted;
  }

  deleteData() {
    let dataDel = this.dataDeleted.id
    this.jobsData = this.jobsData.filter(function (obj) {
      return obj.id !== parseInt(dataDel);
    });
    this.deleteModal.nativeElement.style.display = 'none';

    this.jobs.deleteMSJob(dataDel).subscribe((res) => {
      console.log(res);
      this.getAllJobs();
    });
  }
  // End of delete code

  // Modal Related Codes End

  addMSJob() {
    this.showLoader = true;
    this.jobs.addNewMSJob(this.addJobsForm.getRawValue(), this.serverID).subscribe((res: any) => {
      this.getAllJobs();
      if (res.isError) {
        this.errorMessage = res.errorMessage;
        this.showModal('error');
      }
    }, error => {
      this.showLoader = false;
      console.log(error);
    });
    this.closeModal('jobs');
  }

  activeStatus() {
    let ischecked = this.addJobsForm.value.active;
    if (this.addJobsForm.value.active) {
      this.addJobsForm.value.active = ischecked;
    } else {
      this.addJobsForm.value.active = ischecked;
    }

    if (this.editForm.value.healthCheckURL === false) {
      this.healthCheckUrl = this.editForm.value.msHealthCheckURL;
      this.editForm.controls['msHealthCheckURL'].setValue('');
    }
    else
      this.editForm.controls['msHealthCheckURL'].setValue(
        this.healthCheckUrl?this.healthCheckUrl:this.editForm.controls['msHealthCheckURL'].value
        );

    if (this.addJobsForm.get('microservice').value) {
      this.addJobsForm.get('healthCheckURL').setValue(true);
      this.addJobsForm.get('healthCheckURL').disable();
    }
    else
      this.addJobsForm.get('healthCheckURL').enable();

    this.toggleEditMode = this.editForm.value.active && this.editForm.value.microservice;
    this.createToggleEditMode = this.addJobsForm.value.active && this.addJobsForm.value.microservice;

    if (!this.addJobsForm.get('active').value) {
      this.addJobsForm.get('microservice').disable();
      this.addJobsForm.get('healthCheckURL').disable();
    }
    else
      this.addJobsForm.get('microservice').enable();

    this.setEditFormCheckBoxStates();
    //if (!this.editForm.value.active)
    //this.handleEditRunningStatus();
  }

  private setEditFormCheckBoxStates() {
    if (this.editForm.get('microservice').value) {
      this.editForm.get('healthCheckURL').setValue(true);
      this.editForm.get('healthCheckURL').disable();
    }
    else {
      this.editForm.get('healthCheckURL').enable();
      this.editForm.get('msPortExpression').disable();
      this.editForm.get('msPortNumber').disable();
      this.editForm.get('msNoOfInstances').disable();
    }

    if (!this.editForm.get('active').value) {
      this.editForm.get('microservice').disable();
      this.editForm.get('healthCheckURL').disable();
      this.editForm.get('msPortExpression').disable();
      this.editForm.get('msPortNumber').disable();
      this.editForm.get('msNoOfInstances').disable();
      this.editForm.get('msCoundCriteria').disable();
    }
    else {
      this.editForm.get('microservice').enable();
      if (this.editForm.get('microservice').value) {
        this.editForm.get('msPortExpression').enable();
        this.editForm.get('msPortNumber').enable();
        this.editForm.get('msNoOfInstances').enable();
        this.editForm.get('msCoundCriteria').enable();
      }
    }
  }

  selectedServerId(val) {
    if (val && val.target)
      this.serverID = val.target.value;
  }

  updateJobInfo() {
    const msJobId = this.editForm.value.id;
    this.showLoader = true;
    const value = this.editForm.getRawValue();
    this.jobs.updateMSJob(msJobId, this.editForm.getRawValue()).subscribe((res: any) => {
      this.getAllJobs();
      if (res.isError) {
        this.errorMessage = res.errorMessage;
        this.showModal('error');
      }
    },
      error => {
        console.log(error);
        this.showLoader = false;
      });
    this.closeModal('edit');
  }


  onClickEditRow(updatedData) {
    this.editForm.setValue({
      createdAt: updatedData.createdAt,
      updatedAt: updatedData.updatedAt,
      msAppName: updatedData.msAppName,
      msEligibilityCommand: updatedData.msEligibilityCommand,
      msCoundCriteria: updatedData.msCountCriteria,
      msLaunchingCommand: updatedData.msLaunchingCommand,
      msPortExpression: updatedData.msPortExpression,
      msHealthCheckURL: updatedData.msHealthCheckURL,
      msNoOfInstances: updatedData.msNoOfInstances,
      msPortNumber: updatedData.msPortNumber,
      active: updatedData.active,
      id: updatedData.id,
      microservice: updatedData.microservice,
      healthCheckURL: updatedData.healthCheckURL,
      serverInfo: this.allServers.find(server => server.id === updatedData.serverID),
      serverInfoName: updatedData.serverInfoName
    });
    //this.editForm.controls['active'].setValue(this.default);

    this.editModal.nativeElement.style.display = 'block';
    this.setEditFormCheckBoxStates();
  }

  onClickViewInfo(infoData) {
    this.infoForm.setValue({
      createdAt: infoData.createdAt,
      updatedAt: infoData.updatedAt,
      msAppName: infoData.msAppName,
      msCoundCriteria: infoData.msCountCriteria,
      msEligibilityCommand: infoData.msEligibilityCommand,
      msLaunchingCommand: infoData.msLaunchingCommand,
      msPortExpression: infoData.msPortExpression,
      msHealthCheckURL: infoData.msHealthCheckURL,
      msNoOfInstances: infoData.msNoOfInstances,
      msNoOfInstancesActive: infoData.msNoOfInstancesActive,
      msPortNumber: infoData.msPortNumber,
      active: infoData.active,
      microservice: infoData.microservice,
      healthCheckURL: infoData.healthCheckURL,
      serverInfoName: infoData.serverInfoName
    });
    this.infoModal.nativeElement.style.display = 'block';
  }

  // Server Status color based on running servers
  calculateServerStatus(running, actual) {
    const criticalLevel = (parseInt(running) / parseInt(actual)) * 100;
    if (criticalLevel <= 50) {
      return 'bg-danger';
    } else if (criticalLevel > 50 && criticalLevel <= 75) {
      return 'bg-warning';
    } else {
      return 'bg-success';
    }
  }


  // Sort Logic
  sort(sortdta, elem) {
    let type = elem.getAttribute('data-sort');
    let array = this.jobsData;
    if (type == 'asc') {
      array.sort((a, b) => a[sortdta].localeCompare(b[sortdta]));
      elem.setAttribute('data-sort', 'desc')
    } else {
      array.sort((a, b) => b[sortdta].localeCompare(a[sortdta]));
      elem.setAttribute('data-sort', 'asc')
    }


  }

  myFunction() {
    var popup = document.getElementById("myPopup");
    popup.classList.toggle("show");
  }

  private GetCreateJobFormdata() {
    const formData: FormData = new FormData();
    formData.append('serverInfoName', this.addJobsForm.value.serverInfoName);
    formData.append('msAppName', this.addJobsForm.value.msAppName);
    formData.append('msEligibilityCommand', this.addJobsForm.value.msEligibilityCommand);
    formData.append('msCountCriteria', this.addJobsForm.value.msCoundCriteria);
    formData.append('msLaunchingCommand', this.addJobsForm.value.msLaunchingCommand);
    formData.append('msPortExpression', this.addJobsForm.value.msPortExpression);
    formData.append('msHealthCheckURL', this.addJobsForm.value.msHealthCheckURL);
    formData.append('msNoOfInstances', this.addJobsForm.value.msNoOfInstances);
    formData.append('msNoOfInstancesActive', this.addJobsForm.value.msNoOfInstancesActive);
    formData.append('msPortNumber', this.addJobsForm.value.msPortNumber);
    formData.append('active', this.addJobsForm.value.active);
    formData.append('microservice', this.addJobsForm.value.microservice);
    formData.append('healthCheckURL', this.addJobsForm.value.healthCheckURL);

    return formData;
  }


  ngOnDestroy() {
    this.intervalVal.unsubscribe();
  }

  healthCheckStateChange(event: any) {
    const state = this.editForm.get('healthCheckURL');

  }

  CanShowEditHealthCheckUrl(): boolean {
    return this.editForm.get('healthCheckURL').value;
  }

  CanShowCreateHealthCheckUrl(): boolean {
    return this.addJobsForm.get('healthCheckURL').value;
  }

}