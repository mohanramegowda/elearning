import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ServersService } from '../common/services/servers.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ConstantsURL } from '../common/constants/constants-urls-local';

@Component({
  selector: 'app-servers',
  templateUrl: './servers.component.html',
  styleUrls: ['./servers.component.css']
})
export class ServersComponent implements OnInit {

  @ViewChild('serverModal') serverModal: ElementRef;
  @ViewChild('deleteModal') deleteModal: ElementRef;
  @ViewChild('editModal') editModal: ElementRef;
  @ViewChild('erroMessage') errorModal: ElementRef;
  public dataDeleted: any;
  allServers: any;
  showLoader: boolean = false;
  modalSelection: any;
  addForm: FormGroup;
  editForm: FormGroup;
  fileData: File = null;
  submitted = false;
  errorMessage: string;

  // Get form controls
  get addform() { return this.addForm.controls; }


  constructor(private serverService: ServersService, private fb: FormBuilder, private http: HttpClient) {
    this.addForm = this.fb.group({
      serverName: ['', Validators.required],
      msAppName: ['', Validators.required],
      clientCertificate: [null, Validators.required],
      sudoUser: ['', Validators.required]
    });

    this.editForm = this.fb.group({
      id: '',
      serverName: '',
      msAppName: '',
      clientCertificate: '',
      sudoUser: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.showLoader = true;
    this.getAllServersList();
  }

  getAllServersList() {
    this.serverService.getServersList().subscribe((res) => {
      this.allServers = res;
      this.showLoader = false;
    }, error => {
      console.log(error);
      this.showLoader = false;
    });
  }

  commonSwitchCaseFunction(data) {
    switch (data) {
      case 'edit':
        this.editForm.reset();
        this.modalSelection = this.editModal;
        break;
      case 'delete':
        this.modalSelection = this.deleteModal;
        break;
      case 'server':
        this.addForm.reset();
        this.modalSelection = this.serverModal;
        break;
      case 'error':
        this.modalSelection = this.errorModal;
    }
  }

  closeModal(data) {
    this.commonSwitchCaseFunction(data);
    this.modalSelection.nativeElement.style.display = 'none';
  }

  showModal(data) {
    this.commonSwitchCaseFunction(data);
    this.modalSelection.nativeElement.style.display = 'block';
  }

  deleteConfirmationModal(deleteData) {
    this.dataDeleted = deleteData;
    this.deleteModal.nativeElement.style.display = 'block';
    return this.dataDeleted;
  }

  deleteData() {
    let dataDel = this.dataDeleted.id
    this.allServers = this.allServers.filter(function (obj) {
      return obj.id !== parseInt(dataDel);
    });
    this.deleteModal.nativeElement.style.display = 'none';
    this.serverService.deleteServerInfo(dataDel).subscribe((res) => {
      this.getAllServersList();
    });
  }

  onClickEditRow(editdata) {
    this.editForm.setValue({
      id: editdata.id,
      serverName: editdata.serverName,
      msAppName: editdata.msAppName,
      clientCertificate: '',
      sudoUser: editdata.sudoUser
    });

    this.editModal.nativeElement.style.display = 'block';
  }

  updateServerInfo() {
    const serverId = this.editForm.value.id;
    const updateInfo = { 'serverName': '', 'msAppName': '' };
    updateInfo.serverName = this.editForm.value.serverName;
    updateInfo.msAppName = this.editForm.value.msAppName;
    this.showLoader = true;
    this.serverService.updateServerInfo(serverId, this.getEditServerForData()).subscribe((res:any) => {
      this.getAllServersList();
      if (res.isError) {
        this.errorMessage = res.errorMessage;
        this.showModal('error');
      }
    },
      error => {
        this.showLoader = false;
        console.log(error);
        this.editForm.reset();
      });
    this.closeModal('edit');
  }

  onFileChange(event: any) {
    let fileList: FileList = event.target.files;
    this.fileData = <File>fileList[0];
  }

  addServer() {
    console.log(this.fileData);
    const formData: FormData = new FormData();
    formData.append('serverName', this.addForm.value.serverName);
    formData.append('msAppName', this.addForm.value.msAppName);
    formData.append('clientCertificate', this.fileData);
    formData.append('sudoUser', this.addForm.value.sudoUser);
    this.submitted = true;
    this.showLoader = true;
    this.http.post(ConstantsURL.SVR_Postservers, formData)
      .subscribe((res:any) => {
        this.showLoader = true;
        this.getAllServersList();
        this.addForm.reset();
        if (res.isError) {
          this.errorMessage = res.errorMessage;
          this.showModal('error');
        }
      }, error => {
        console.log(error);
        this.addForm.reset();
        this.closeModal('server');
        this.showModal('error');
      });
    this.closeModal('server');
  }

  private getEditServerForData() {
    const formData: FormData = new FormData();
    formData.append('serverName', this.editForm.value.serverName);
    formData.append('msAppName', this.editForm.value.msAppName);
    formData.append('clientCertificate', this.fileData);
    formData.append('sudoUser', this.editForm.value.sudoUser);
    return formData;
  }

}
