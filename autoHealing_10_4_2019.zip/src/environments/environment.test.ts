export const environment = {
    production: true,
    environmentName: 'test',
    apiUrl: 'http://themisto.emea.fedex.com:9006/'
};