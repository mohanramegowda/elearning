export const environment = {
    production: false,
    environmentName: 'DEV',
    apiUrl: 'https://dione.emea.fedex.com/'
};