//todo need to get the api url
export const environment = {
    production: true,
    environmentName: 'Production',
    apiUrl: 'http://192.168.30.163:9006/'
};