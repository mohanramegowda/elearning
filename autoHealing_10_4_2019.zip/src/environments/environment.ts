export const environment = {
    production: false,
    environmentName: 'local',
    apiUrl: 'http://192.168.30.190:9006/'
};